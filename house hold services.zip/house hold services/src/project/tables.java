/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project;
import java.sql.*;
import javax.swing.JOptionPane;

/**
 *
 * @author HP
 */
public class tables {
    public static void main(String[] args) {
       
    
    
        Connection con=null;
        Statement st=null;
        try
        {
           con=connectionprovider.getCon();
           st=con.createStatement();
           
          // st.executeUpdate("create table users(Firstname varchar(40),Lastname varchar(40),Email varchar(200),Phonenumber int(10),Question varchar(100),Answer varchar(100),Password varchar(20),confirm varchar(20),status varchar(20))");
         // st.executeUpdate("create table employee(Name varchar(200),Address varchar(500),Phonenumber varchar(10),Email varchar(200),Job varchar(300) ,status varchar(20))");
          
         // st.executeUpdate("create table booked(Name varchar(200),PhoneNumber varchar(10),Email varchar(200),Address varchar(500),Services varchar(200),EmployeeName varchar(200),Problem varchar(600),DateofBooking varchar(20),dateofservicesprovied varchar(20))");
         st.executeUpdate("create table verification(Name varchar(200),PhoneNumber varchar(10),Email varchar(200),Address varchar(500),Services varchar(200),EmployeeName varchar(200),Problem varchar(600),DateofBooking varchar(20),dateofservicesprovied varchar(20))");
          JOptionPane.showMessageDialog(null,"table created successfully");
                      
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
        }
                    
        
        finally
        {
                try
                {
                    con.close();
                    st.close();
                }
                catch(Exception e)
                    {
                        
                    }
                
    
        }
        
    }
}

    
